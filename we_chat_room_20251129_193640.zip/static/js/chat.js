document.addEventListener('DOMContentLoaded', function() {
    // 获取URL中的昵称参数
    const urlParams = new URLSearchParams(window.location.search);
    const nickname = urlParams.get('nickname');
    
    if (!nickname) {
        // 如果没有昵称参数，返回登录页
        window.location.href = '/';
        return;
    }

    // DOM元素
    const messagesContainer = document.getElementById('messages-container');
    const messageInput = document.getElementById('message-input');
    const sendBtn = document.getElementById('send-btn');
    const logoutBtn = document.getElementById('logout-btn');
    const usersList = document.getElementById('users-list');
    const emojiBtn = document.getElementById('emoji-btn');
    const emojiPanel = document.getElementById('emoji-panel');

    // WebSocket连接
    const socket = io();
    const room = 'default';

    // 初始化连接
    socket.on('connect', function() {
        console.log('已连接到服务器');
        // 加入聊天室
        socket.emit('join', { nickname: nickname, room: room });
    });

    // 接收欢迎消息
    socket.on('welcome', function(data) {
        addSystemMessage(data.message);
    });

    // 接收新消息
    socket.on('new_message', function(data) {
        const isSelf = data.sender === nickname;
        addMessage(data.sender, data.message, data.type, isSelf);
    });

    // 用户加入通知
    socket.on('user_joined', function(data) {
        addSystemMessage(`${data.nickname} 加入了聊天室`);
    });

    // 用户离开通知
    socket.on('user_left', function(data) {
        addSystemMessage(`${data.nickname} 离开了聊天室`);
    });

    // 更新在线用户列表
    socket.on('update_users', function(data) {
        updateUsersList(data.users);
    });

    // 错误处理
    socket.on('error', function(data) {
        alert(data.message);
        if (data.message.includes('昵称已被使用')) {
            window.location.href = '/';
        }
    });

    // 连接断开处理
    socket.on('disconnect', function() {
        console.log('与服务器断开连接');
        addSystemMessage('已与服务器断开连接，请刷新页面重试');
    });

    // 发送消息
    function sendMessage() {
        const message = messageInput.value.trim();
        if (!message) return;

        // 发送消息到服务器
        socket.emit('send_message', { message: message });
        
        // 清空输入框
        messageInput.value = '';
        // 保持输入框聚焦
        messageInput.focus();
    }

    // 获取当前时间的格式化字符串
    function getCurrentTime() {
        const now = new Date();
        const hours = now.getHours().toString().padStart(2, '0');
        const minutes = now.getMinutes().toString().padStart(2, '0');
        return `${hours}:${minutes}`;
    }

    // 添加消息到消息容器
    function addMessage(sender, content, type, isSelf) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${isSelf ? 'self' : 'other'}`;
        
        // 创建消息头部（包含发送者和时间）
        const messageHeader = document.createElement('div');
        messageHeader.className = 'message-header';
        
        // 发送者名称
        const senderSpan = document.createElement('span');
        senderSpan.className = 'sender';
        senderSpan.textContent = sender + (isSelf ? ' (我)' : '');
        messageHeader.appendChild(senderSpan);
        
        // 发送时间
        const timeSpan = document.createElement('span');
        timeSpan.className = 'time';
        timeSpan.textContent = getCurrentTime();
        messageHeader.appendChild(timeSpan);
        
        messageDiv.appendChild(messageHeader);
        
        // 根据消息类型处理内容
        const contentDiv = document.createElement('div');
        contentDiv.className = 'content';
        
        switch(type) {
            case 'movie':
                // 电影类型消息，使用iframe嵌入视频播放器
                const movieUrl = encodeURIComponent(content);
                const playerUrl = `https://jx.m3u8.tv/jiexi/?url=${movieUrl}`;
                contentDiv.innerHTML = `
                    <div class="movie-container">
                        <div class="movie-header">
                            <span>🎬 电影播放</span>
                            <a href="${content}" target="_blank" class="original-link">查看原链接</a>
                        </div>
                        <iframe 
                            src="${playerUrl}" 
                            class="movie-iframe" 
                            frameborder="0" 
                            allowfullscreen
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                            sandbox="allow-scripts allow-same-origin allow-popups allow-popups-to-escape-sandbox allow-top-navigation-by-user-activation">
                        </iframe>
                    </div>
                `;
                break;
            case 'ai':
                // AI对话类型消息 - 川小农助手
                contentDiv.innerHTML = `🤖 ${content}`;
                
                // 模拟AI回复 - 实现川小农助手功能
                setTimeout(() => {
                    const reply = generateAIReply(content);
                    addMessage('川小农', reply, 'text', false);
                }, 1000);
                break;
            default:
                // 普通文本消息，支持换行和基本格式
                contentDiv.textContent = content;
                break;
        }
        
        messageDiv.appendChild(contentDiv);
        messagesContainer.appendChild(messageDiv);
        
        // 滚动到底部
        scrollToBottom();
    }

    // 添加系统消息
    function addSystemMessage(message) {
        const messageDiv = document.createElement('div');
        messageDiv.className = 'message system';
        messageDiv.textContent = message;
        messagesContainer.appendChild(messageDiv);
        
        // 滚动到底部
        scrollToBottom();
    }

    // 更新用户列表
    function updateUsersList(users) {
        usersList.innerHTML = '';
        users.forEach(user => {
            const li = document.createElement('li');
            // 如果是当前用户，添加特殊标记
            if (user === nickname) {
                li.textContent = `${user} (我)`;
                li.style.fontWeight = 'bold';
            } else {
                li.textContent = user;
            }
            usersList.appendChild(li);
        });
    }

    // 滚动到底部
    function scrollToBottom() {
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }

    // 退出登录
    function logout() {
        socket.disconnect();
        window.location.href = '/';
    }

    // 切换Emoji面板
    function toggleEmojiPanel() {
        emojiPanel.classList.toggle('show');
    }

    // 插入Emoji
    function insertEmoji(emoji) {
        messageInput.value += emoji;
        messageInput.focus();
        emojiPanel.classList.remove('show');
    }

    // 事件监听
    sendBtn.addEventListener('click', sendMessage);
    
    messageInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });
    
    logoutBtn.addEventListener('click', logout);
    
    emojiBtn.addEventListener('click', toggleEmojiPanel);
    
    // 点击页面其他区域关闭Emoji面板
    document.addEventListener('click', function(e) {
        if (!emojiBtn.contains(e.target) && !emojiPanel.contains(e.target)) {
            emojiPanel.classList.remove('show');
        }
    });
    
    // Emoji点击事件
    document.querySelectorAll('.emoji').forEach(emoji => {
        emoji.addEventListener('click', function() {
            insertEmoji(this.textContent);
        });
    });

    // 页面加载完成后请求在线用户列表
    setTimeout(() => {
        socket.emit('get_online_users');
    }, 1000);
    
    // 窗口关闭时断开连接
    window.addEventListener('beforeunload', function() {
        socket.disconnect();
    });

    // 生成川小农AI助手回复的函数
    function generateAIReply(userInput) {
        const input = userInput.toLowerCase().trim();
        
        // 检查是否包含其他学校的信息
        const otherSchools = ['清华', '北大', '复旦', '交大', '浙大', '中科大', '南大', '华科', '武大', '北师大'];
        for (const school of otherSchools) {
            if (input.includes(school)) {
                return `很抱歉，我只提供与四川农业大学相关的信息。😕`;
            }
        }
        
        // 处理四川农业大学相关问题
        if (input.includes('四川农业大学') || input.includes('川农大') || input.includes('川农')) {
            if (input.includes('位置') || input.includes('地址') || input.includes('在哪里')) {
                return '四川农业大学有三个校区：雅安校区位于四川省雅安市雨城区新康路46号；成都校区位于四川省成都市温江区惠民路211号；都江堰校区位于四川省成都市都江堰市建设路288号。';
            } else if (input.includes('创建') || input.includes('成立') || input.includes('建校') || input.includes('历史')) {
                return '四川农业大学创建于1906年，前身是四川通省农业学堂，是我国最早的涉农高等院校之一。';
            } else if (input.includes('专业') || input.includes('学科') || input.includes('王牌')) {
                return '四川农业大学的优势学科包括作物学、畜牧学、兽医学、林学、农林经济管理等，其中作物学入选国家一流学科建设名单。';
            } else if (input.includes('校长') || input.includes('领导')) {
                return '四川农业大学现任校长是吴德教授。';
            } else if (input.includes('简称') || input.includes('缩写')) {
                return '四川农业大学的简称是川农大或川农，英文缩写为SICAU。';
            } else {
                return '四川农业大学是一所以生物科技为特色，农业科技为优势，多学科协调发展的国家"211工程"重点建设大学和国家"双一流"建设高校。';
            }
        }
        
        // 处理生成古诗的指令
        if (input.includes('古诗') || input.includes('写诗') || input.includes('七言')) {
            const poems = [
                '春风吹绿校园柳，川农学子读书忙。\n书山有路勤为径，学海无涯苦作航。',
                '雅雨烹茶香满室，蓉城访学志四方。\n川农精神传千古，农业振兴谱新章。',
                '泮池荷影映朝阳，梧桐叶落知秋凉。\n莘莘学子追梦想，川农明天更辉煌。',
                '岷山千里雪皑皑，青衣江水润田垓。\n川农儿女多奇志，科技兴农展雄才。',
                '桃花盛开满校园，蜜蜂飞舞采蜜甜。\n川农风光无限好，立德树人谱新篇。'
            ];
            return poems[Math.floor(Math.random() * poems.length)];
        }
        
        // 处理生成通知的指令
        if (input.includes('通知') || input.includes('公告')) {
            // 提取通知主题
            const themeMatch = userInput.match(/关于(.+?)的通知/) || userInput.match(/通知主题：(.+?)/);
            const theme = themeMatch ? themeMatch[1] : '近期工作安排';
            
            // 根据主题生成不同内容
            let content = '';
            if (theme.includes('会议') || theme.includes('开会')) {
                content = '为进一步加强工作沟通与协调，经研究决定召开相关工作会议。请参会人员提前做好准备，准时参加。';
            } else if (theme.includes('放假') || theme.includes('假期')) {
                content = '根据学校工作安排，现将放假相关事宜通知如下，请全体师生遵照执行。';
            } else if (theme.includes('报名') || theme.includes('申请')) {
                content = '现将相关报名/申请事宜通知如下，请符合条件的师生积极参与，按时提交材料。';
            } else {
                content = '现将相关工作安排通知如下，请全体师生知晓并遵照执行。';
            }
            
            // 生成通知格式
            return `关于${theme}的通知\n全校师生：\n${content}\n特此通知。\n四川农业大学\n${new Date().getFullYear()}年${new Date().getMonth() + 1}月${new Date().getDate()}日`;
        }
        
        // 检查是否包含功能范围内的关键词
        const validKeywords = ['四川农业大学', '川农大', '川农', '古诗', '写诗', '七言', '通知', '公告'];
        let hasValidKeyword = false;
        for (const keyword of validKeywords) {
            if (input.includes(keyword)) {
                hasValidKeyword = true;
                break;
            }
        }
        
        // 如果没有有效关键词，返回超出功能范围的回复
        if (!hasValidKeyword) {
            return '一边去。';
        }
        
        // 默认回复
        return '您好！我是四川农业大学的AI小助手川小农，请问有什么可以帮助您的吗？';
    }
});