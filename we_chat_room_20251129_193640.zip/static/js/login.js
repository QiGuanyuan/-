document.addEventListener('DOMContentLoaded', function() {
    const nicknameInput = document.getElementById('nickname');
    const serverSelect = document.getElementById('server');
    const loginBtn = document.getElementById('login-btn');
    const errorMessage = document.getElementById('error-message');

    // 加载服务器配置
    fetch('/config')
        .then(response => response.json())
        .then(config => {
            if (config.servers && config.servers.length > 0) {
                // 清空现有选项
                serverSelect.innerHTML = '';
                // 添加配置的服务器选项
                config.servers.forEach(server => {
                    const option = document.createElement('option');
                    option.value = server.url;
                    option.textContent = server.name;
                    serverSelect.appendChild(option);
                });
            }
        })
        .catch(error => {
            console.error('加载配置失败:', error);
        });

    // 登录处理
    loginBtn.addEventListener('click', function() {
        const nickname = nicknameInput.value.trim();
        const serverUrl = serverSelect.value;
        
        // 简单验证
        if (!nickname) {
            showError('请输入昵称');
            return;
        }
        
        // 发送登录请求
        fetch('/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                nickname: nickname,
                server_url: serverUrl
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                // 登录成功，跳转到聊天室页面
                window.location.href = `/chat?nickname=${encodeURIComponent(nickname)}`;
            } else {
                showError(data.message || '登录失败');
            }
        })
        .catch(error => {
            console.error('登录请求失败:', error);
            showError('网络错误，请稍后重试');
        });
    });

    // 回车键登录
    nicknameInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            loginBtn.click();
        }
    });

    // 显示错误信息
    function showError(message) {
        errorMessage.textContent = message;
        // 3秒后自动清除错误信息
        setTimeout(() => {
            errorMessage.textContent = '';
        }, 3000);
    }
});